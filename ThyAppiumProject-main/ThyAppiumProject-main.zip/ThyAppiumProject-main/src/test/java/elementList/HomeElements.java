package element;
import org.openqa.selenium.By;

public class HomePageElements{

    public static By BookAFlyButton = By.id("com.turkishairlines.mobile:id/acMain_btnBooking");

}
